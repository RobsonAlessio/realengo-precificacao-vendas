--
-- PostgreSQL database dump
--

\restrict QE9rGh304V3lNbLkMuec89A5QuHqa4R77Hogu0zahbTHKflQG0Wv4MVmeeP69af

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: precificacao
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO precificacao;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: precificacao
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(100) NOT NULL,
    status character varying(20) NOT NULL,
    event_metadata json,
    created_at timestamp without time zone
);


ALTER TABLE public.audit_logs OWNER TO precificacao;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: precificacao
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO precificacao;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: precificacao
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: parametros_representante; Type: TABLE; Schema: public; Owner: precificacao
--

CREATE TABLE public.parametros_representante (
    id integer NOT NULL,
    representante character varying(120) NOT NULL,
    data_vigencia date NOT NULL,
    meta_frete_1 numeric(10,4),
    meta_frete_2 numeric(10,4),
    meta_frete_3 numeric(10,4),
    margem_parbo numeric(8,6),
    margem_branco numeric(8,6),
    margem_integral numeric(8,6),
    codigo_representante integer,
    criado_em timestamp without time zone,
    atualizado_em timestamp without time zone
);


ALTER TABLE public.parametros_representante OWNER TO precificacao;

--
-- Name: parametros_representante_id_seq; Type: SEQUENCE; Schema: public; Owner: precificacao
--

CREATE SEQUENCE public.parametros_representante_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parametros_representante_id_seq OWNER TO precificacao;

--
-- Name: parametros_representante_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: precificacao
--

ALTER SEQUENCE public.parametros_representante_id_seq OWNED BY public.parametros_representante.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: precificacao
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying NOT NULL,
    hashed_password character varying,
    is_active boolean,
    created_at timestamp without time zone,
    role character varying(50),
    auth_provider character varying(20) DEFAULT 'local'::character varying NOT NULL
);


ALTER TABLE public.users OWNER TO precificacao;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: precificacao
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO precificacao;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: precificacao
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: parametros_representante id; Type: DEFAULT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.parametros_representante ALTER COLUMN id SET DEFAULT nextval('public.parametros_representante_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: precificacao
--

COPY public.alembic_version (version_num) FROM stdin;
0002
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: precificacao
--

COPY public.audit_logs (id, user_id, action, status, event_metadata, created_at) FROM stdin;
1	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:25:42.198543
2	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:26:05.727491
3	1	CONFIG_UPDATE	success	{"updated_by": "admin"}	2026-04-06 12:26:19.853737
4	4	USER_CREATED_LDAP	success	{"username": "robson.alessio"}	2026-04-06 12:27:50.168877
5	4	LOGIN_PENDING_ROLE	warning	{"username": "robson.alessio"}	2026-04-06 12:27:50.171653
6	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:27:58.249781
7	4	LOGIN_PENDING_ROLE	warning	{"username": "robson.alessio"}	2026-04-06 12:29:18.083494
8	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:31:33.228148
9	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:33:28.422172
10	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:34:50.201232
11	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:42:17.426027
12	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:42:29.106342
13	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:43:08.127675
14	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:46:07.691451
15	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:47:23.667588
16	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:47:47.165973
17	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:51:17.783446
18	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:53:45.717345
19	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 12:56:50.195463
20	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:04:36.344586
21	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:04:53.243167
22	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:08:17.226597
23	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:08:36.503492
24	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:11:31.406484
25	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:19:24.265707
26	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:19:31.936428
27	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:19:38.192984
28	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:20:35.863748
29	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:21:10.143533
30	4	LOGIN_PENDING_ROLE	warning	{"username": "robson.alessio"}	2026-04-06 13:22:59.709434
31	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:24:08.283375
32	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:25:03.090616
33	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:28:51.138842
34	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:29:10.937442
35	1	PARAM_UPDATE	success	{"count": 1, "updated_by": "admin"}	2026-04-06 13:29:39.752376
36	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 13:30:06.046039
37	1	USER_UPDATED	success	{"updated_user_id": 4, "updated_by": "admin", "role": "viewer", "is_active": null}	2026-04-06 13:30:23.093914
38	4	LOGIN_SUCCESS	success	{"username": "robson.alessio", "auth_provider": "ldap"}	2026-04-06 13:30:47.706782
39	1	USER_UPDATED	success	{"updated_user_id": 4, "updated_by": "admin", "role": "editor", "is_active": null}	2026-04-06 13:31:07.645024
40	4	PARAM_UPDATE	success	{"count": 1, "updated_by": "robson.alessio"}	2026-04-06 13:31:13.462905
41	1	USER_UPDATED	success	{"updated_user_id": 4, "updated_by": "admin", "role": "viewer", "is_active": null}	2026-04-06 13:31:19.12416
42	1	USER_UPDATED	success	{"updated_user_id": 4, "updated_by": "admin", "role": "admin", "is_active": null}	2026-04-06 13:31:40.966008
43	4	LOGIN_SUCCESS	success	{"username": "robson.alessio", "auth_provider": "ldap"}	2026-04-06 13:31:56.222732
44	1	USER_UPDATED	success	{"updated_user_id": 4, "updated_by": "admin", "role": "viewer", "is_active": null}	2026-04-06 13:32:05.294227
45	1	USER_UPDATED	success	{"updated_user_id": 4, "updated_by": "admin", "role": null, "is_active": false}	2026-04-06 13:32:24.674454
46	4	LOGIN_SUCCESS	success	{"username": "robson.alessio", "auth_provider": "ldap"}	2026-04-06 13:32:43.152707
47	4	LOGIN_SUCCESS	success	{"username": "robson.alessio", "auth_provider": "ldap"}	2026-04-06 13:32:54.416122
48	1	USER_UPDATED	success	{"updated_user_id": 4, "updated_by": "admin", "role": null, "is_active": true}	2026-04-06 13:33:01.4684
49	\N	LOGIN_FAILURE	error	{"username": "jose.warnier"}	2026-04-06 14:28:01.688795
50	5	USER_CREATED_LDAP	success	{"username": "jose.warnier"}	2026-04-06 14:28:08.617681
51	5	LOGIN_PENDING_ROLE	warning	{"username": "jose.warnier"}	2026-04-06 14:28:08.621428
52	1	USER_UPDATED	success	{"updated_user_id": 5, "updated_by": "admin", "role": "editor", "is_active": null}	2026-04-06 14:32:58.045514
53	\N	LOGIN_FAILURE	error	{"username": "jose.warnier"}	2026-04-06 14:33:57.766091
54	5	LOGIN_SUCCESS	success	{"username": "jose.warnier", "auth_provider": "ldap"}	2026-04-06 14:34:07.361842
55	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 14:48:11.262362
56	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 14:52:06.704108
57	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 14:52:15.270032
58	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 18:13:08.631356
59	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 18:13:40.940692
60	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 18:14:33.036746
61	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 18:14:43.161008
62	1	USER_UPDATED	success	{"updated_user_id": 4, "updated_by": "admin", "role": "admin", "is_active": null}	2026-04-06 18:14:57.897922
63	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 18:25:34.856521
64	1	USER_PASSWORD_CHANGED	success	{"target_user": "admin", "changed_by": "admin"}	2026-04-06 18:28:13.240667
65	1	LOGIN_SUCCESS	success	{"username": "admin", "auth_provider": "local"}	2026-04-06 18:28:19.71596
66	1	PARAM_UPDATE	success	{"count": 1, "updated_by": "admin"}	2026-04-06 18:41:32.151696
67	1	PARAM_UPDATE	success	{"count": 1, "updated_by": "admin"}	2026-04-06 18:41:54.023365
68	1	PARAM_UPDATE	success	{"count": 1, "updated_by": "admin"}	2026-04-06 18:46:28.309895
69	4	LOGIN_SUCCESS	success	{"username": "robson.alessio", "auth_provider": "ldap"}	2026-04-06 19:18:41.435657
70	6	USER_CREATED_LDAP	success	{"username": "alexandre.feltrin"}	2026-04-06 19:25:55.405869
71	6	LOGIN_PENDING_ROLE	warning	{"username": "alexandre.feltrin"}	2026-04-06 19:25:55.41053
72	4	USER_UPDATED	success	{"updated_user_id": 6, "updated_by": "robson.alessio", "role": "admin", "is_active": null}	2026-04-06 19:26:42.484872
73	6	LOGIN_SUCCESS	success	{"username": "alexandre.feltrin", "auth_provider": "ldap"}	2026-04-06 19:27:01.808272
\.


--
-- Data for Name: parametros_representante; Type: TABLE DATA; Schema: public; Owner: precificacao
--

COPY public.parametros_representante (id, representante, data_vigencia, meta_frete_1, meta_frete_2, meta_frete_3, margem_parbo, margem_branco, margem_integral, codigo_representante, criado_em, atualizado_em) FROM stdin;
1	EDVALDO	2026-01-01	18.7200	\N	\N	0.120000	0.130000	0.150000	87	2026-04-01 17:48:24.256786	2026-04-01 17:48:24.256793
2	GILVAN	2026-01-01	18.5000	\N	\N	0.120000	0.140000	0.150000	151	2026-04-01 17:48:24.278623	2026-04-01 17:48:24.278632
4	JAQUELINE	2026-01-01	16.8000	\N	\N	0.140000	0.120000	0.150000	147	2026-04-01 17:48:24.284322	2026-04-01 17:48:24.284329
5	COMPER	2026-01-01	3.8500	\N	\N	0.120000	0.140000	0.150000	98	2026-04-01 17:48:24.28706	2026-04-01 17:48:24.287067
6	PEREIRA	2026-01-01	18.5000	\N	\N	0.110000	0.120000	0.150000	88	2026-04-01 17:48:24.289711	2026-04-01 17:48:24.289717
7	STELA	2026-01-01	14.5000	\N	\N	0.120000	0.110000	0.150000	150	2026-04-01 17:48:24.292244	2026-04-01 17:48:24.292251
8	ZE FILHO	2026-01-01	18.8000	\N	\N	0.110000	0.100000	0.130000	138	2026-04-01 17:48:24.294692	2026-04-01 17:48:24.294699
9	BARBOSA	2026-01-01	18.5000	\N	\N	0.100000	0.100000	0.150000	20	2026-04-01 17:48:24.297146	2026-04-01 17:48:24.297152
10	DINO	2026-01-01	16.4000	\N	\N	0.100000	0.100000	0.150000	4	2026-04-01 17:48:24.299783	2026-04-01 17:48:24.299789
11	MOURA	2026-01-01	18.5000	\N	\N	0.110000	0.120000	0.150000	102	2026-04-01 17:48:24.302269	2026-04-01 17:48:24.302276
12	MANOEL	2026-01-01	18.9000	\N	\N	0.110000	0.110000	0.150000	37	2026-04-01 17:48:24.304498	2026-04-01 17:48:24.304502
14	COSTA	2026-01-01	8.5000	\N	\N	0.130000	0.120000	0.150000	141	2026-04-01 17:48:24.3082	2026-04-01 17:48:24.308204
16	ROMERO	2026-01-01	12.6000	\N	\N	0.100000	0.100000	0.130000	40	2026-04-01 17:48:24.311323	2026-04-01 17:48:24.311327
18	FRED	2026-01-01	18.0000	\N	\N	0.100000	0.100000	0.120000	41	2026-04-01 17:48:24.314481	2026-04-01 17:48:24.314484
19	LUIZ CARLOS	2026-01-01	17.5000	\N	\N	0.130000	0.120000	0.150000	153	2026-04-01 17:48:24.316133	2026-04-01 17:48:24.316136
20	DIEGO	2026-01-01	17.0000	\N	\N	0.130000	0.120000	0.150000	43	2026-04-01 17:48:24.317774	2026-04-01 17:48:24.317778
21	THALYSSON	2026-01-01	13.0000	\N	\N	0.120000	0.110000	0.150000	154	2026-04-01 17:48:24.319506	2026-04-01 17:48:24.319512
23	WHARLEY	2026-01-01	9.4000	\N	\N	0.120000	0.110000	0.150000	158	2026-04-01 17:48:24.322827	2026-04-01 17:48:24.322831
24	MOISES	2026-01-01	13.8000	\N	\N	0.120000	0.110000	0.150000	159	2026-04-01 17:48:24.324437	2026-04-01 17:48:24.324441
25	EDVALDO	2026-02-01	18.7200	\N	\N	0.120000	0.130000	0.150000	87	2026-04-01 17:48:24.357406	2026-04-01 17:48:24.357415
26	GILVAN	2026-02-01	18.5000	\N	\N	0.120000	0.140000	0.150000	151	2026-04-01 17:48:24.36076	2026-04-01 17:48:24.360767
28	JAQUELINE	2026-02-01	16.8000	\N	\N	0.140000	0.120000	0.150000	147	2026-04-01 17:48:24.365647	2026-04-01 17:48:24.365653
29	COMPER	2026-02-01	3.8500	\N	\N	0.120000	0.140000	0.150000	98	2026-04-01 17:48:24.368027	2026-04-01 17:48:24.368032
30	PEREIRA	2026-02-01	18.5000	\N	\N	0.110000	0.120000	0.150000	88	2026-04-01 17:48:24.370309	2026-04-01 17:48:24.370315
31	STELA	2026-02-01	14.5000	\N	\N	0.120000	0.110000	0.150000	150	2026-04-01 17:48:24.372545	2026-04-01 17:48:24.37255
32	ZE FILHO	2026-02-01	18.8000	\N	\N	0.110000	0.100000	0.130000	138	2026-04-01 17:48:24.374839	2026-04-01 17:48:24.374845
33	BARBOSA	2026-02-01	18.5000	\N	\N	0.100000	0.100000	0.150000	20	2026-04-01 17:48:24.377163	2026-04-01 17:48:24.377169
34	DINO	2026-02-01	16.4000	\N	\N	0.100000	0.100000	0.150000	4	2026-04-01 17:48:24.379562	2026-04-01 17:48:24.379568
35	MOURA	2026-02-01	18.5000	\N	\N	0.110000	0.120000	0.150000	102	2026-04-01 17:48:24.381873	2026-04-01 17:48:24.381879
36	MANOEL	2026-02-01	18.9000	\N	\N	0.110000	0.110000	0.150000	37	2026-04-01 17:48:24.384359	2026-04-01 17:48:24.384365
38	COSTA	2026-02-01	8.5000	\N	\N	0.130000	0.120000	0.150000	141	2026-04-01 17:48:24.389293	2026-04-01 17:48:24.389299
40	ROMERO	2026-02-01	12.6000	\N	\N	0.100000	0.100000	0.130000	40	2026-04-01 17:48:24.393841	2026-04-01 17:48:24.393847
42	FRED	2026-02-01	18.0000	\N	\N	0.100000	0.100000	0.120000	41	2026-04-01 17:48:24.398299	2026-04-01 17:48:24.398305
43	LUIZ CARLOS	2026-02-01	17.5000	\N	\N	0.130000	0.120000	0.150000	153	2026-04-01 17:48:24.400589	2026-04-01 17:48:24.400595
44	DIEGO	2026-02-01	17.0000	\N	\N	0.130000	0.120000	0.150000	43	2026-04-01 17:48:24.402894	2026-04-01 17:48:24.4029
45	THALYSSON	2026-02-01	13.0000	\N	\N	0.120000	0.110000	0.150000	154	2026-04-01 17:48:24.405118	2026-04-01 17:48:24.405124
47	WHARLEY	2026-02-01	9.4000	\N	\N	0.120000	0.110000	0.150000	158	2026-04-01 17:48:24.409383	2026-04-01 17:48:24.409389
48	MOISES	2026-02-01	13.8000	\N	\N	0.120000	0.110000	0.150000	159	2026-04-01 17:48:24.41158	2026-04-01 17:48:24.411586
49	EDVALDO	2026-03-01	18.7200	\N	\N	0.120000	0.130000	0.150000	87	2026-04-01 17:48:24.443224	2026-04-01 17:48:24.443229
50	GILVAN	2026-03-01	18.5000	\N	\N	0.120000	0.140000	0.150000	151	2026-04-01 17:48:24.445603	2026-04-01 17:48:24.445608
51	JAQUELINE	2026-03-01	13.0000	\N	\N	0.140000	0.120000	0.150000	147	2026-04-01 17:48:24.447462	2026-04-01 17:48:24.447466
52	COMPER	2026-03-01	3.8500	\N	\N	0.120000	0.140000	0.150000	98	2026-04-01 17:48:24.449143	2026-04-01 17:48:24.449147
53	PEREIRA	2026-03-01	18.5000	\N	\N	0.110000	0.120000	0.150000	88	2026-04-01 17:48:24.450818	2026-04-01 17:48:24.450822
54	STELA	2026-03-01	16.5000	\N	\N	0.120000	0.110000	0.150000	150	2026-04-01 17:48:24.452432	2026-04-01 17:48:24.452436
55	ZE FILHO	2026-03-01	19.0000	\N	\N	0.110000	0.100000	0.130000	138	2026-04-01 17:48:24.454097	2026-04-01 17:48:24.454101
56	BARBOSA	2026-03-01	18.5000	\N	\N	0.100000	0.100000	0.150000	20	2026-04-01 17:48:24.455743	2026-04-01 17:48:24.455747
57	DINO	2026-03-01	16.4000	\N	\N	0.100000	0.100000	0.150000	4	2026-04-01 17:48:24.457456	2026-04-01 17:48:24.45746
58	MOURA	2026-03-01	18.5000	\N	\N	0.110000	0.120000	0.150000	102	2026-04-01 17:48:24.459124	2026-04-01 17:48:24.459128
60	COSTA	2026-03-01	9.5000	\N	\N	0.130000	0.120000	0.150000	141	2026-04-01 17:48:24.462677	2026-04-01 17:48:24.462681
62	ROMERO	2026-03-01	12.6000	\N	\N	0.100000	0.100000	0.130000	40	2026-04-01 17:48:24.465848	2026-04-01 17:48:24.465852
63	FRED	2026-03-01	18.5000	\N	\N	0.100000	0.100000	0.120000	41	2026-04-01 17:48:24.4677	2026-04-01 17:48:24.467704
64	LUIZ CARLOS	2026-03-01	17.5000	\N	\N	0.130000	0.120000	0.150000	153	2026-04-01 17:48:24.469324	2026-04-01 17:48:24.469328
65	DIEGO	2026-03-01	17.0000	\N	\N	0.130000	0.120000	0.150000	43	2026-04-01 17:48:24.471154	2026-04-01 17:48:24.471158
66	THALYSSON	2026-03-01	16.9000	\N	\N	0.120000	0.110000	0.150000	154	2026-04-01 17:48:24.472796	2026-04-01 17:48:24.472801
68	WHARLEY	2026-03-01	16.5000	\N	\N	0.120000	0.110000	0.150000	158	2026-04-01 17:48:24.475947	2026-04-01 17:48:24.475951
69	MOISES	2026-03-01	16.0000	\N	\N	0.120000	0.110000	0.150000	159	2026-04-01 17:48:24.477572	2026-04-01 17:48:24.477577
76	ROBERTO	2026-04-02	2.0000	1.0000	1.3000	0.070000	0.080000	0.090000	3	2026-04-02 23:50:44.393442	2026-04-02 23:50:44.393449
73	DINO	2026-04-01	16.4000	\N	\N	0.100000	0.100000	0.150000	4	2026-04-01 18:49:45.678625	2026-04-06 18:46:28.304272
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: precificacao
--

COPY public.users (id, username, hashed_password, is_active, created_at, role, auth_provider) FROM stdin;
2	viewer_user	$2b$12$test	t	\N	viewer	local
3	ldap_user	\N	t	\N	viewer	ldap
5	jose.warnier	\N	t	2026-04-06 14:28:08.607266	editor	ldap
4	robson.alessio	\N	t	2026-04-06 12:27:50.16421	admin	ldap
1	admin	$2b$12$Veaw2..biOjh9OUMMG/zbO2NN5o5x3/6elZXDfNCZPufKTB74cK3.	t	2026-04-01 17:21:20.353618	admin	local
6	alexandre.feltrin	\N	t	2026-04-06 19:25:55.39914	admin	ldap
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: precificacao
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 73, true);


--
-- Name: parametros_representante_id_seq; Type: SEQUENCE SET; Schema: public; Owner: precificacao
--

SELECT pg_catalog.setval('public.parametros_representante_id_seq', 82, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: precificacao
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: parametros_representante parametros_representante_pkey; Type: CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.parametros_representante
    ADD CONSTRAINT parametros_representante_pkey PRIMARY KEY (id);


--
-- Name: parametros_representante uq_rep_data; Type: CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.parametros_representante
    ADD CONSTRAINT uq_rep_data UNIQUE (representante, data_vigencia);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_id; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE INDEX ix_audit_logs_id ON public.audit_logs USING btree (id);


--
-- Name: ix_parametros_representante_id; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE INDEX ix_parametros_representante_id ON public.parametros_representante USING btree (id);


--
-- Name: ix_parametros_representante_representante; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE INDEX ix_parametros_representante_representante ON public.parametros_representante USING btree (representante);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict QE9rGh304V3lNbLkMuec89A5QuHqa4R77Hogu0zahbTHKflQG0Wv4MVmeeP69af

