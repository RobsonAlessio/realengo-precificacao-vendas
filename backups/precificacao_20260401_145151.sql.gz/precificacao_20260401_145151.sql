--
-- PostgreSQL database dump
--

\restrict cxqSlbTtQyc0PZtStrFRbFSz4hexHklj3XgdFlpRWdIgih7SkM21bgqV6tLictb

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: precificacao
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO precificacao;

--
-- Name: parametros_representante; Type: TABLE; Schema: public; Owner: precificacao
--

CREATE TABLE public.parametros_representante (
    id integer NOT NULL,
    representante character varying(120) NOT NULL,
    data_vigencia date NOT NULL,
    meta_frete_1 numeric(10,4),
    meta_frete_2 numeric(10,4),
    meta_frete_3 numeric(10,4),
    margem_parbo numeric(8,6),
    margem_branco numeric(8,6),
    margem_integral numeric(8,6),
    codigo_representante integer,
    criado_em timestamp without time zone,
    atualizado_em timestamp without time zone
);


ALTER TABLE public.parametros_representante OWNER TO precificacao;

--
-- Name: parametros_representante_id_seq; Type: SEQUENCE; Schema: public; Owner: precificacao
--

CREATE SEQUENCE public.parametros_representante_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parametros_representante_id_seq OWNER TO precificacao;

--
-- Name: parametros_representante_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: precificacao
--

ALTER SEQUENCE public.parametros_representante_id_seq OWNED BY public.parametros_representante.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: precificacao
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying NOT NULL,
    hashed_password character varying NOT NULL,
    is_active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO precificacao;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: precificacao
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO precificacao;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: precificacao
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: parametros_representante id; Type: DEFAULT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.parametros_representante ALTER COLUMN id SET DEFAULT nextval('public.parametros_representante_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: precificacao
--

COPY public.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: parametros_representante; Type: TABLE DATA; Schema: public; Owner: precificacao
--

COPY public.parametros_representante (id, representante, data_vigencia, meta_frete_1, meta_frete_2, meta_frete_3, margem_parbo, margem_branco, margem_integral, codigo_representante, criado_em, atualizado_em) FROM stdin;
1	EDVALDO	2026-01-01	18.7200	\N	\N	0.120000	0.130000	0.150000	87	2026-04-01 17:48:24.256786	2026-04-01 17:48:24.256793
2	GILVAN	2026-01-01	18.5000	\N	\N	0.120000	0.140000	0.150000	151	2026-04-01 17:48:24.278623	2026-04-01 17:48:24.278632
4	JAQUELINE	2026-01-01	16.8000	\N	\N	0.140000	0.120000	0.150000	147	2026-04-01 17:48:24.284322	2026-04-01 17:48:24.284329
5	COMPER	2026-01-01	3.8500	\N	\N	0.120000	0.140000	0.150000	98	2026-04-01 17:48:24.28706	2026-04-01 17:48:24.287067
6	PEREIRA	2026-01-01	18.5000	\N	\N	0.110000	0.120000	0.150000	88	2026-04-01 17:48:24.289711	2026-04-01 17:48:24.289717
7	STELA	2026-01-01	14.5000	\N	\N	0.120000	0.110000	0.150000	150	2026-04-01 17:48:24.292244	2026-04-01 17:48:24.292251
8	ZE FILHO	2026-01-01	18.8000	\N	\N	0.110000	0.100000	0.130000	138	2026-04-01 17:48:24.294692	2026-04-01 17:48:24.294699
9	BARBOSA	2026-01-01	18.5000	\N	\N	0.100000	0.100000	0.150000	20	2026-04-01 17:48:24.297146	2026-04-01 17:48:24.297152
10	DINO	2026-01-01	16.4000	\N	\N	0.100000	0.100000	0.150000	4	2026-04-01 17:48:24.299783	2026-04-01 17:48:24.299789
11	MOURA	2026-01-01	18.5000	\N	\N	0.110000	0.120000	0.150000	102	2026-04-01 17:48:24.302269	2026-04-01 17:48:24.302276
12	MANOEL	2026-01-01	18.9000	\N	\N	0.110000	0.110000	0.150000	37	2026-04-01 17:48:24.304498	2026-04-01 17:48:24.304502
14	COSTA	2026-01-01	8.5000	\N	\N	0.130000	0.120000	0.150000	141	2026-04-01 17:48:24.3082	2026-04-01 17:48:24.308204
16	ROMERO	2026-01-01	12.6000	\N	\N	0.100000	0.100000	0.130000	40	2026-04-01 17:48:24.311323	2026-04-01 17:48:24.311327
18	FRED	2026-01-01	18.0000	\N	\N	0.100000	0.100000	0.120000	41	2026-04-01 17:48:24.314481	2026-04-01 17:48:24.314484
19	LUIZ CARLOS	2026-01-01	17.5000	\N	\N	0.130000	0.120000	0.150000	153	2026-04-01 17:48:24.316133	2026-04-01 17:48:24.316136
20	DIEGO	2026-01-01	17.0000	\N	\N	0.130000	0.120000	0.150000	43	2026-04-01 17:48:24.317774	2026-04-01 17:48:24.317778
21	THALYSSON	2026-01-01	13.0000	\N	\N	0.120000	0.110000	0.150000	154	2026-04-01 17:48:24.319506	2026-04-01 17:48:24.319512
23	WHARLEY	2026-01-01	9.4000	\N	\N	0.120000	0.110000	0.150000	158	2026-04-01 17:48:24.322827	2026-04-01 17:48:24.322831
24	MOISES	2026-01-01	13.8000	\N	\N	0.120000	0.110000	0.150000	159	2026-04-01 17:48:24.324437	2026-04-01 17:48:24.324441
25	EDVALDO	2026-02-01	18.7200	\N	\N	0.120000	0.130000	0.150000	87	2026-04-01 17:48:24.357406	2026-04-01 17:48:24.357415
26	GILVAN	2026-02-01	18.5000	\N	\N	0.120000	0.140000	0.150000	151	2026-04-01 17:48:24.36076	2026-04-01 17:48:24.360767
28	JAQUELINE	2026-02-01	16.8000	\N	\N	0.140000	0.120000	0.150000	147	2026-04-01 17:48:24.365647	2026-04-01 17:48:24.365653
29	COMPER	2026-02-01	3.8500	\N	\N	0.120000	0.140000	0.150000	98	2026-04-01 17:48:24.368027	2026-04-01 17:48:24.368032
30	PEREIRA	2026-02-01	18.5000	\N	\N	0.110000	0.120000	0.150000	88	2026-04-01 17:48:24.370309	2026-04-01 17:48:24.370315
31	STELA	2026-02-01	14.5000	\N	\N	0.120000	0.110000	0.150000	150	2026-04-01 17:48:24.372545	2026-04-01 17:48:24.37255
32	ZE FILHO	2026-02-01	18.8000	\N	\N	0.110000	0.100000	0.130000	138	2026-04-01 17:48:24.374839	2026-04-01 17:48:24.374845
33	BARBOSA	2026-02-01	18.5000	\N	\N	0.100000	0.100000	0.150000	20	2026-04-01 17:48:24.377163	2026-04-01 17:48:24.377169
34	DINO	2026-02-01	16.4000	\N	\N	0.100000	0.100000	0.150000	4	2026-04-01 17:48:24.379562	2026-04-01 17:48:24.379568
35	MOURA	2026-02-01	18.5000	\N	\N	0.110000	0.120000	0.150000	102	2026-04-01 17:48:24.381873	2026-04-01 17:48:24.381879
36	MANOEL	2026-02-01	18.9000	\N	\N	0.110000	0.110000	0.150000	37	2026-04-01 17:48:24.384359	2026-04-01 17:48:24.384365
38	COSTA	2026-02-01	8.5000	\N	\N	0.130000	0.120000	0.150000	141	2026-04-01 17:48:24.389293	2026-04-01 17:48:24.389299
40	ROMERO	2026-02-01	12.6000	\N	\N	0.100000	0.100000	0.130000	40	2026-04-01 17:48:24.393841	2026-04-01 17:48:24.393847
42	FRED	2026-02-01	18.0000	\N	\N	0.100000	0.100000	0.120000	41	2026-04-01 17:48:24.398299	2026-04-01 17:48:24.398305
43	LUIZ CARLOS	2026-02-01	17.5000	\N	\N	0.130000	0.120000	0.150000	153	2026-04-01 17:48:24.400589	2026-04-01 17:48:24.400595
44	DIEGO	2026-02-01	17.0000	\N	\N	0.130000	0.120000	0.150000	43	2026-04-01 17:48:24.402894	2026-04-01 17:48:24.4029
45	THALYSSON	2026-02-01	13.0000	\N	\N	0.120000	0.110000	0.150000	154	2026-04-01 17:48:24.405118	2026-04-01 17:48:24.405124
47	WHARLEY	2026-02-01	9.4000	\N	\N	0.120000	0.110000	0.150000	158	2026-04-01 17:48:24.409383	2026-04-01 17:48:24.409389
48	MOISES	2026-02-01	13.8000	\N	\N	0.120000	0.110000	0.150000	159	2026-04-01 17:48:24.41158	2026-04-01 17:48:24.411586
49	EDVALDO	2026-03-01	18.7200	\N	\N	0.120000	0.130000	0.150000	87	2026-04-01 17:48:24.443224	2026-04-01 17:48:24.443229
50	GILVAN	2026-03-01	18.5000	\N	\N	0.120000	0.140000	0.150000	151	2026-04-01 17:48:24.445603	2026-04-01 17:48:24.445608
51	JAQUELINE	2026-03-01	13.0000	\N	\N	0.140000	0.120000	0.150000	147	2026-04-01 17:48:24.447462	2026-04-01 17:48:24.447466
52	COMPER	2026-03-01	3.8500	\N	\N	0.120000	0.140000	0.150000	98	2026-04-01 17:48:24.449143	2026-04-01 17:48:24.449147
53	PEREIRA	2026-03-01	18.5000	\N	\N	0.110000	0.120000	0.150000	88	2026-04-01 17:48:24.450818	2026-04-01 17:48:24.450822
54	STELA	2026-03-01	16.5000	\N	\N	0.120000	0.110000	0.150000	150	2026-04-01 17:48:24.452432	2026-04-01 17:48:24.452436
55	ZE FILHO	2026-03-01	19.0000	\N	\N	0.110000	0.100000	0.130000	138	2026-04-01 17:48:24.454097	2026-04-01 17:48:24.454101
56	BARBOSA	2026-03-01	18.5000	\N	\N	0.100000	0.100000	0.150000	20	2026-04-01 17:48:24.455743	2026-04-01 17:48:24.455747
57	DINO	2026-03-01	16.4000	\N	\N	0.100000	0.100000	0.150000	4	2026-04-01 17:48:24.457456	2026-04-01 17:48:24.45746
58	MOURA	2026-03-01	18.5000	\N	\N	0.110000	0.120000	0.150000	102	2026-04-01 17:48:24.459124	2026-04-01 17:48:24.459128
60	COSTA	2026-03-01	9.5000	\N	\N	0.130000	0.120000	0.150000	141	2026-04-01 17:48:24.462677	2026-04-01 17:48:24.462681
62	ROMERO	2026-03-01	12.6000	\N	\N	0.100000	0.100000	0.130000	40	2026-04-01 17:48:24.465848	2026-04-01 17:48:24.465852
63	FRED	2026-03-01	18.5000	\N	\N	0.100000	0.100000	0.120000	41	2026-04-01 17:48:24.4677	2026-04-01 17:48:24.467704
64	LUIZ CARLOS	2026-03-01	17.5000	\N	\N	0.130000	0.120000	0.150000	153	2026-04-01 17:48:24.469324	2026-04-01 17:48:24.469328
65	DIEGO	2026-03-01	17.0000	\N	\N	0.130000	0.120000	0.150000	43	2026-04-01 17:48:24.471154	2026-04-01 17:48:24.471158
66	THALYSSON	2026-03-01	16.9000	\N	\N	0.120000	0.110000	0.150000	154	2026-04-01 17:48:24.472796	2026-04-01 17:48:24.472801
68	WHARLEY	2026-03-01	16.5000	\N	\N	0.120000	0.110000	0.150000	158	2026-04-01 17:48:24.475947	2026-04-01 17:48:24.475951
69	MOISES	2026-03-01	16.0000	\N	\N	0.120000	0.110000	0.150000	159	2026-04-01 17:48:24.477572	2026-04-01 17:48:24.477577
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: precificacao
--

COPY public.users (id, username, hashed_password, is_active, created_at) FROM stdin;
1	admin	$2b$12$bWd5Fl/aaWxJaWfFYW9KOuVw1iDqyWQT.YaViiedygTlWoB4ExBvy	t	2026-04-01 17:21:20.353618
\.


--
-- Name: parametros_representante_id_seq; Type: SEQUENCE SET; Schema: public; Owner: precificacao
--

SELECT pg_catalog.setval('public.parametros_representante_id_seq', 69, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: precificacao
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: parametros_representante parametros_representante_pkey; Type: CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.parametros_representante
    ADD CONSTRAINT parametros_representante_pkey PRIMARY KEY (id);


--
-- Name: parametros_representante uq_rep_data; Type: CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.parametros_representante
    ADD CONSTRAINT uq_rep_data UNIQUE (representante, data_vigencia);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: precificacao
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_parametros_representante_id; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE INDEX ix_parametros_representante_id ON public.parametros_representante USING btree (id);


--
-- Name: ix_parametros_representante_representante; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE INDEX ix_parametros_representante_representante ON public.parametros_representante USING btree (representante);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: precificacao
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- PostgreSQL database dump complete
--

\unrestrict cxqSlbTtQyc0PZtStrFRbFSz4hexHklj3XgdFlpRWdIgih7SkM21bgqV6tLictb

